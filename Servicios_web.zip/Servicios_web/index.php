<?php
header('Location: App/view/ajax.html');
?>