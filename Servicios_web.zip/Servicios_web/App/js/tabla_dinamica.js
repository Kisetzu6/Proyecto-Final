$(document).ready(iniciar);

function iniciar() {
    $("#agregar_fila").on("click", agregarFila);
    $("#eliminar_fila").on("click", eliminarFila);
}
function agregarFila() {
    var nombre_usuario = $("#nombre_usuario").val();
    var edad_usuario = $("#edad_usuario").val();
    var ciudad_usuario = $("#ciudad_usuario").val();
    var id_usuario = $("#id_usuario").val();

    if (nombre_usuario && edad_usuario && ciudad_usuario && id_usuario) {
        $("#tabla_dinamica").append("<tr><td>" + nombre_usuario + "</td><td>" + edad_usuario + "</td><td>" + ciudad_usuario + "</td><td>" + id_usuario + "</td></tr>");
    }else {
        alert("Tienes que llenar los campos")
    }
}
function eliminarFila() {
    $("#tabla_dinamica tr:last").remove();
}