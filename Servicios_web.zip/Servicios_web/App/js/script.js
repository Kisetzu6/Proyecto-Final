
$(document).ready(inicial) //Cuando el documento este listo, Iniciar funcion saludar

function inicial() {
  alert("Hola, bienvenido a los ejercicios de AJAX");
  //console.log($("#correo"));
  conts = $("#correo").val("@ciaf.edu.co");
  //Envio datos desde JS a la vista ajax.html
  $("#correo").val("@ciaf.edu.co");
  $(".saludar").on("click", saludar_desde_boton);
  $(".saludar2").on("click", saludar_desde_boton2);
  $(".saludar3").on("click", saludar_desde_boton4);
  $(".saludar4").on("click", saludar_desde_boton5);
};


function saludar_desde_boton() {
  alert("Cristiano")
  $("body").removeClass("bg-arcangel bg-angel bg-sasuke")
  $("body").addClass("bg-cristiano text-white")
}
function saludar_desde_boton2() {
  alert("Arcangel")

  $("body").removeClass("bg-angel bg-cristiano bg-sasuke text-white")
  $("body").addClass("bg-arcangel text-dark")
}
function saludar_desde_boton4() {
  alert("Angel")
  $("body").removeClass("bg-arcangel bg-cristiano bg-sasuke")
  $("body").addClass("bg-angel text-white")
}
function saludar_desde_boton5() {
  alert("Sasuke")
  $("body").removeClass("bg-arcangel bg-cristiano bg-angel bg-primary bg-gradient")
  $("body").addClass("bg-sasuke text-white")

}