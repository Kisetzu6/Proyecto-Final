

 function contarPalabras() {
    let texto = document.getElementById("Ejercicio1").value;

    
    texto = texto.toLowerCase();

    
    texto = texto.replace(/[^\w\sáéíóúüñ]/gi, '');

  
    const palabras = texto.trim().split(/\s+/);

    
    const contador = {};
    for (let palabra of palabras) {
      if (palabra) {
        contador[palabra] = (contador[palabra] || 0) + 1;
      }
    }

    
    const resultado = Object.entries(contador)
      .map(([palabra, cantidad]) => `<li><strong>${palabra}</strong>: ${cantidad}</li>`)
      .join('');

    document.getElementById("resultado1").innerHTML = resultado;
  }

let Ejercicio1Container = document.getElementById("Ejercicio1Container");
let Ejercicio2Container = document.getElementById("Ejercicio2Container");
let Ejercicio3Container = document.getElementById("Ejercicio3Container");
let Ejercicio4Container = document.getElementById("Ejercicio4Container");
let Ejercicio5Container = document.getElementById("Ejercicio5Container");

Ejercicio1Container.style.display = "none";
Ejercicio2Container.style.display = "none";
Ejercicio3Container.style.display = "none";
Ejercicio4Container.style.display = "none";
Ejercicio5Container.style.display = "none";

let navEjercicio1 = document.getElementById("navEjercicio1");
let navEjercicio2 = document.getElementById("navEjercicio2");
let navEjercicio3 = document.getElementById("navEjercicio3");
let navEjercicio4 = document.getElementById("navEjercicio4");
let navEjercicio5 = document.getElementById("navEjercicio5");



navEjercicio1.addEventListener("click", () => {
  Ejercicio1Container.style.display = "block";
  Ejercicio2Container.style.display = "none";
  Ejercicio3Container.style.display = "none";
  Ejercicio4Container.style.display = "none";
  Ejercicio5Container.style.display = "none";
})

navEjercicio2.addEventListener("click", () => {
  Ejercicio2Container.style.display = "block";
  Ejercicio1Container.style.display = "none";
  Ejercicio3Container.style.display = "none";
  Ejercicio4Container.style.display = "none";
  Ejercicio5Container.style.display = "none";
})

navEjercicio3.addEventListener("click", () => {
  Ejercicio3Container.style.display = "block";
  Ejercicio1Container.style.display = "none";
  Ejercicio2Container.style.display = "none";
  Ejercicio4Container.style.display = "none";
  Ejercicio5Container.style.display = "none";
})

navEjercicio4.addEventListener("click", () => {
  Ejercicio4Container.style.display = "block";
  Ejercicio1Container.style.display = "none";
  Ejercicio2Container.style.display = "none";
  Ejercicio3Container.style.display = "none";
  Ejercicio5Container.style.display = "none";
})

navEjercicio5.addEventListener("click", () => {
  Ejercicio5Container.style.display = "block";
  Ejercicio1Container.style.display = "none";
  Ejercicio2Container.style.display = "none";
  Ejercicio3Container.style.display = "none";
  Ejercicio4Container.style.display = "none";
})


let selectEjercicio2 = document.getElementById("selectEjercicio2");

selectEjercicio2.addEventListener("change", () => {
  document.getElementById("resultado2").innerHTML = "";

  let selectedValue = selectEjercicio2.value;
  console.log("Valor seleccionado:", selectedValue);
 let products = obtenerProductosBaratos(selectedValue);
 products.forEach(product => {
    let li = document.createElement("li");
    li.textContent = `${product}`;
    document.getElementById("resultado2").appendChild(li);
  })
});

const products = [
  // Tecnología
  { categoria: "tecn", nombre: "Lenovo", precio: 20 },
  { categoria: "tecn", nombre: "iPhone", precio: 12 },
  { categoria: "tecn", nombre: "Audífonos Sony", precio: 10 },

  // Ropa
  { categoria: "ropa", nombre: "Camisetas", precio: 15 },
  { categoria: "ropa", nombre: "Jeans", precio: 22 },
  { categoria: "ropa", nombre: "Chaqueta", precio: 30 },

  // Electrodomésticos
  { categoria: "electro", nombre: "Lavadora", precio: 25 },
  { categoria: "electro", nombre: "Refrigerador", precio: 50 },
  { categoria: "electro", nombre: "Microondas", precio: 50 },

  // Automotriz
  { categoria: "auto", nombre: "BMW", precio: 20 },
  { categoria: "auto", nombre: "Toyota", precio: 24 },
  { categoria: "auto", nombre: "Chevrolet", precio: 50 }
];


function obtenerProductosBaratos(categoria) {
  const nombresProductos = products
    .filter(item => item.categoria === categoria && item.precio < 25)
    .map(item => item.nombre);

  return nombresProductos.length > 0 ? nombresProductos : ["No hay productos menores a 25."];
}
const inputEjercicio3 = document.getElementById("Ejercicio3");
const btnEjercicio3 = document.getElementById("btnEjercicio3");
const resultado3 = document.getElementById("resultado3");

function capitalizarNombreCompleto(nombre) {
  return nombre
    .trim()                                
    .split(/\s+/)                          
    .map(palabra => 
      palabra.charAt(0).toUpperCase() + palabra.slice(1).toLowerCase()
    )
    .join(" ");                            // Une con un solo espacio
}

btnEjercicio3.addEventListener("click", () => {
  const valorOriginal = inputEjercicio3.value;
  if (valorOriginal.trim() === "") return;

  const nombreCorregido = capitalizarNombreCompleto(valorOriginal);

  const li = document.createElement("li");
  li.textContent = nombreCorregido;
  resultado3.appendChild(li);

  inputEjercicio3.value = ""; // Limpiar input
});

const listaDePalabras = ["roma", "ramo", "amor", "mora", "caro", "arco", "risa", "sira", "sol", "los"];

document.getElementById("btnEjercicio4").addEventListener("click", function () {
  const input = document.getElementById("Ejercicio4").value.trim().toLowerCase();

  const ordenar = palabra => palabra.split('').sort().join('');

  const palabraOrdenada = ordenar(input);

  const anagramas = listaDePalabras.filter(palabra => 
    palabra !== input && ordenar(palabra) === palabraOrdenada
  );

  const resultado4 = document.getElementById("resultado4");
  if (anagramas.length > 0) {
    resultado4.innerHTML = anagramas.map(p => `<li>${p}</li>`).join('');
  } else {
    resultado4.innerHTML = `<li>No se encontraron anagramas.</li>`;
  }
});

const datos = [
  "ana:10",
  "juan:5",
  "ana:3",
  "pedro:7",
  "juan:4",
  "ana:2"
];

document.getElementById("btnEjercicio5").addEventListener("click", function () {
  const input = document.getElementById("Ejercicio5").value.trim().toLowerCase();

  const filtrados = input 
    ? datos.filter(d => d.startsWith(input + ":")) 
    : datos;

  const totales = {};

  filtrados.forEach(item => {
    const [usuario, puntos] = item.split(":");
    const puntosNum = parseInt(puntos);

    if (totales[usuario]) {
      totales[usuario] += puntosNum;
    } else {
      totales[usuario] = puntosNum;
    }
  });

  const resultado = Object.entries(totales)
    .map(([usuario, puntos]) => `<li><strong>${usuario}</strong>: ${puntos} puntos</li>`)
    .join('');

  document.getElementById("resultado5").innerHTML = resultado || "<li>No hay resultados.</li>";
});
