$(document).ready(iniciar);

function iniciar() {
    $("#buscar").on("change", cambiarEfecto);
    $("#cambiar_imagen").on("change", cambiarImagen);
    $(".imagen1").hide();
    //$("#campo_texto").on("keypress", verificarTexto());

    $("#campo_texto").on("keyup", function(event) {
        console.log(event.key); // Muestra la tecla presionada en la consola, Solo la tecla y no todo el objeto event como tal. Si no tenemos el event.key, nos muestra todo el objeto event.
        if (event.key === "Enter") { 
            verificarTexto(event.key); //Al presionar Enter, se llama a la función verificarTexto y se le pasa la tecla presionada como argumento. De lo contrario, se podria quitar el event.key si no queremos que este sea mencionada.
        }
        if (event.key === "a" || event.key === "A") {
            $("#noticia1").append("<h2>Has presionado la letra A</h2>");
            $("#noticia1").css("background-color", "black");
            $("#noticia1").css("color", "white");
            $("#noticia1").css("padding", "20px");
        }
        verificarTexto(event.key);

    });
}
function verificarTexto(tecla) {
    alert("Has presionado la tecla: " + tecla);
    
    
    
}
function cambiarEfecto() {
    valor_seleccionado = $("#buscar").val();
 
    if (valor_seleccionado == "slideup") {
        $("#noticia1").slideUp(2000);
        //completed
    }else if (valor_seleccionado == "slidedown") {
        $("#noticia1").slideDown(2000);
    } else if (valor_seleccionado == "fadeout") {
        $("#noticia1").fadeOut(2000);
    } else if (valor_seleccionado == "fadein") {
        $("#noticia1").fadeIn(2000);
    }
}

function cambiarImagen() {
    valor_seleccionado = $("#cambiar_imagen").val();
    
    if (valor_seleccionado == "imagen1") {
        $(".imagen1").show();
        $(".imagen2").hide();
        
    }else if (valor_seleccionado == "imagen2") {
        $(".imagen2").show();
        $(".imagen1").hide();
    }
}
